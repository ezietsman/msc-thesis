from pylab import *

X1 = load('run1_flat.dat')
x1 = X1[:,0]
y1 = X1[:,1]

X2 = load('flattened.fou')
x2 = X2[:,0]
y2 = X2[:,1]


subplot(211)

#plot(x1,y1,'.')
scatter(x1,y1,s=0.8,faceted=False)
xlabel('Fractional Day')
ylabel('Relative Magnitude')
title('Flattened Lightcurve')
ylim(max(y1)+0.25,min(y1)-0.25)


subplot(212)

plot(x2,y2,'k-')
xlabel('Frequency (cycles/day)')
ylabel('Amplitude (mag)')
vlines(3600,0.0025,0.003,'k-')
vlines(950,0.0025,0.003,'k-')
text(3350,0.0035,'DNO',fontsize=10)
text(700,0.0035,'lpDNO',fontsize=10)
xlim(0,7000)
title('Periodogram')

show()

