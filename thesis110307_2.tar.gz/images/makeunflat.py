from pylab import *

X1 = load('ec2117ans_1_cc.dat')
x1 = X1[:,0]
y1 = X1[:,2]

X2 = load('unflattend.fou')
x2 = X2[:,0]
y2 = X2[:,1]


subplot(211)

#plot(x1,y1,'.')
scatter(x1,y1,s=0.8,faceted=False)
xlabel('Fractional Day')
ylabel('Relative Magnitude')
title('Original Lightcurve')
ylim(max(y1)+0.25,min(y1)-0.25)


subplot(212)

plot(x2,y2,'k-')
xlabel('Frequency (cycles/day)')
ylabel('Amplitude (mag)')
title('Periodogram')
xlim(0,7000)

savefig('unflattened.png')

show()

